#include <WiFi.h>
#include <PubSubClient.h>

const char *ssid = "UPV-PSK";
const char *password = "giirob-pr2-2023";
const char *mqtt_broker = "mqtt.dsic.upv.es";
const char *mqtt_username = "giirob";
const char *mqtt_password = "UPV2024";
const int mqtt_port = 1883;
const char *topic_escucha = "giirob/pr2/estacion/leds";

WiFiClient espClient;
PubSubClient client(espClient);

void setup() {
  Serial.begin(115200);
  
  on_setup();

  conectarWiFi();
  client.setServer(mqtt_broker, mqtt_port);
  client.setCallback(callback); 
}

void loop() {
  if (!client.connected()) {
    reconnect();
  }
  client.loop();
}