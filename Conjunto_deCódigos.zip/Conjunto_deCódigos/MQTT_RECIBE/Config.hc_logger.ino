const int LED_SENSOR1 = 13;
const int LED_SENSOR2 = 12;
const int LED_READY   = 14;
const int LED_PALET   = 15;

void on_setup() {
  pinMode(LED_SENSOR1, OUTPUT);
  pinMode(LED_SENSOR2, OUTPUT);
  pinMode(LED_READY, OUTPUT);
  pinMode(LED_PALET, OUTPUT);
}